'''
  #
  # Run class
  #   Creates a run with needed attributes
  #     * See endRun.py for example implementation 
  #     
  # toDo: make attributes private(@property decorator), add setters(@{attr_name}.setter decorator)
  #
'''

import com.uniconnect.uniflow as uniflow
from java.sql import SQLException

## CLASS
class PoolRun:

  '''
    # Class variable used for logging the error location
  '''
  errorLocation = ''

  '''
    # Init function
    #
  '''
  def __init__(self, switchboard, poolRunId):
    self.switchboard = switchboard
    self.poolRunId = poolRunId
    self.curCon = None
    self.curPar = None
    self.curPos = None
    self.status = None

    # Set values
    self.setPoolRunValues()

  '''
    # Sets run attributes based on Id
    #
  '''
  def setPoolRunValues(self):
    errorLocation = '<<<<< BEGIN: setPoolRunValues >>>>>'
    poolRunId = self.poolRunId
    cCon  = None
    cPar  = None
    cPos  = None
    cRes  = None
    try:
      cQuery = '''
        SELECT 
          currentContainerId, 
          currentParentId,
          currentParentPosition,
          completedResult
        FROM poolRuns
        WHERE poolRunId = ?
      '''
      cQueryStmt = self.switchboard.connection.prepareStatement(cQuery)
      cQueryStmt.setString(1, poolRunId)
      cRs = cQueryStmt.executeQuery()
      while cRs.next():
        cCon = cRs.getString('currentContainerId')
        cPar = cRs.getString('currentParentId')
        cPos = cRs.getString('currentParentPosition')
        cRes = cRs.getString('completedResult')
      self.curCon = cCon
      self.curPar = cPar
      self.curPos = cPos
      self.status = cRes
      cRs.close()
      cQueryStmt.close()

      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
    except Exception as e:
      self.switchboard.log("---*** EXCEPTION ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except StandardError as e:
      self.switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except SystemException as e:
      self.switchboard.log("---*** UNIFlow SystemException ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except SQLException as e:
      self.switchboard.log("---*** SQLException ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except BaseException as e:
      self.switchboard.log("---*** PYTHON EXCEPTION ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except TypeError as e:
      self.switchboard.log("---*** TYPE ERROR ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except:
      self.switchboard.log("---*** UNSPECIFIED ERROR ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  ## GETTERS
  def getPoolRunId(self):
    return self.poolRunId

  def getCurrentContainer(self):
    return self.curCon

  def getCurrentParent(self):
    return self.curPar
  
  def getCurrentPosition(self):
    return self.curPos
  
  def getCurStatus(self):
    return self.status


  ## Setters
  def setCurrentContainer(self, newCurCon):
    self.curCon = newCurCon

  def setCurrentParent(self, newCurPar):
    self.curPar = newCurPar

  def setCurrentPosition(self, newCurPos):
    self.curPos = newCurPos

  def setCurStatus(self, newStatus):
    self.status = newStatus




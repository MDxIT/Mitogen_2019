from run import Run

## CLASS
class CreateRun_dev(Run):
  def __init__(self, switchboard, runId):

    ## INHERITANCE
    Run.__init__(self, switchboard, runId)

    self.specimen_method = 'spec_meth'
    self.current_container = 'cur_con'
    self.current_parent = 'cur_par'
    self.current_position = 'cur_pos'
    self.parent_run = 0
    self.run_type = 'workflow'
    self.lEventId = self.switchboard.eventId
    self.eventId = self.switchboard.eventId


  def setSpecimenMethod(self, specimen_method):
    self.specimen_method = specimen_method
  def setCurrentContainer(self, current_container):
    self.current_container = current_container
  def setCurrentParent(self, current_parent):
    self.current_parent = current_parent
  def setCurrentPosition(self, current_position):
    self.current_position = current_position
  def setParentWorkFlow(self, parent_run):
    self.parent_run = parent_run
  def setRunType(self, run_type):
    self.run_type = run_type

  def setWorkFlow(self, workflowRun=0):
    if workflowRun != 0:
      self.parent_run = workflowRun
      self.run_type = 'process'

  def setParentAndPos(self, parent, position):
    self.current_parent = parent
    self.current_position = position







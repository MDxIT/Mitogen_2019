
import json
from com.uniconnect.uniflow.exception import SystemException
from java.sql import SQLException
from groupingContainer import GroupingContainer
import csv

class ManualDownload(GroupingContainer):

  def __init__(self, switchboard, containerId):
    GroupingContainer.__init__(self, switchboard, containerId)

  def processCSV(self, methodVer):
    
    RunIds = self.getRunIds()
    CtlIds = self.getControlRunIds()
    csvArrTest = []

    # for ctlRun in CtlIds:
    #   ctlJsonArr = getConfigByCtlRun(self.switchboard, ctlRun, methodVer)
    #   ctlRow = makeCtlRow(self.switchboard, ctlJsonArr, ctlRun)
    #   csvArrTest.append(ctlRow)

    for run in RunIds:
      thisJsonArr = self.getConfigByRun(run, methodVer)
      runRow = self.makeRow(self.switchboard, thisJsonArr, run)
      csvArrTest.append(runRow)

    return csvArrTest


  def writeCsv(self, methodVer, filePath):

    listToWrite = self.processCSV(methodVer)

    try:
      with open(filePath, 'w') as f:
        writer = csv.writer(f, dialect='excel')
        writer.writerows(listToWrite)

      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
    except:
      self.switchboard.log("---*** UNSPECIFIED ERROR AT GROUPINGCONTAINER WRITECSV ***---")
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  def getJsonArray(self, rs, colNum):
    jsonArr = []
    while rs.next():
      for i in range(1,colNum + 1):
        thisJSON = json.loads(rs.getString(i))
        jsonArr.append(thisJSON)

    return jsonArr


  def getConfigByRun_dev(self, runId, methodVer):
    jsonQuery = '''
      SELECT
        CASE andd.definerType
          WHEN 'metaData' 
            THEN JSON_OBJECT('order', andd.sequence, 'value', fcp.inputName, 'valType', 'metaData') 
          WHEN 'loadData'
            THEN JSON_OBJECT('order', andd.sequence, 'value', andd.dataType, 'valType', 'loadData', 'loadDataDefId', andd.loadDataAnalysisDataDefinitionId)
          WHEN 'specimenColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', sr.currentContainerId, 'valType', 'specimenId')
          WHEN 'locationColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', sr.currentParentPosition, 'valType', 'specimenLocation')
          END AS 'thisJSON'
      FROM analysisDataDefinition andd
      INNER JOIN specimenRuns sr ON sr.runId = ?
      LEFT JOIN formInputSettings fis ON fis.id = andd.formInputSettingsId
      LEFT JOIN formConfigurableParts fcp ON fcp.id = fis.formConfigurablePartsId
      LEFT JOIN analysisData ad ON ad.analysisDataDefinitionId = andd.id
      WHERE andd.analysisMethodVersionsId = ?
      ORDER BY andd.sequence
    ''' 

    jsonQueryStmt = self.switchboard.connection.prepareStatement(jsonQuery)
    jsonQueryStmt.setString(1, runId)
    jsonQueryStmt.setString(2, methodVer)

    jsonRs = jsonQueryStmt.executeQuery()

    runConfig = []

    while jsonRs.next():

      config = jsonRs.getString('thisJSON')

      runConfig.append(config)

    print runConfig

  def getConfigByRun(self, runId, methodVer):
    jsonQuery = '''
      SELECT
        CASE andd.definerType
          WHEN 'metaData' 
            THEN JSON_OBJECT('order', andd.sequence, 'value', fcp.inputName, 'valType', 'metaData') 
          WHEN 'loadData'
            THEN JSON_OBJECT('order', andd.sequence, 'value', andd.dataType, 'valType', 'loadData', 'loadDataDefId', andd.loadDataAnalysisDataDefinitionId)
          WHEN 'specimenColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', sr.currentContainerId, 'valType', 'specimenId')
          WHEN 'locationColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', sr.currentParentPosition, 'valType', 'specimenLocation')
          END AS 'thisJSON'
      FROM analysisDataDefinition andd
      INNER JOIN specimenRuns sr ON sr.runId = ?
      LEFT JOIN formInputSettings fis ON fis.id = andd.formInputSettingsId
      LEFT JOIN formConfigurableParts fcp ON fcp.id = fis.formConfigurablePartsId
      LEFT JOIN analysisData ad ON ad.analysisDataDefinitionId = andd.id
      WHERE andd.analysisMethodVersionsId = ?
      ORDER BY andd.sequence
    ''' 

    jsonQueryStmt = self.switchboard.connection.prepareStatement(jsonQuery)
    jsonQueryStmt.setString(1, runId)
    jsonQueryStmt.setString(2, methodVer)
    resSet = jsonQueryStmt.executeQuery()
    metaData = resSet.getMetaData()
    colNum = metaData.getColumnCount()

    thisJsonArr = self.getJsonArray(resSet, colNum)
    jsonQueryStmt.close()

    return thisJsonArr


  def getMetaDataVal(self, fieldName, runId):

    thisResult = ''
    metaDataQuery = '''
      SELECT ''' + fieldName + '''
      FROM vw_runmetadata 
      WHERE runId = ?
    ''' 

    metaValStmt = self.switchboard.connection.prepareStatement(metaDataQuery)
    metaValStmt.setString(1, runId)
    metaDataRS = metaValStmt.executeQuery()

    while metaDataRS.next():
      thisResult = metaDataRS.getString(1)
    metaValStmt.close()

    return thisResult


'''
  # Return single load data value pased on the data definition id and run
  # 
  # @param<int> dataDefId
  # @param<string> runId
  #
  # @return thisResult 
  #
'''
def getLoadVal(self, dataDefId, runId):
  thisResult = ''

  resultQuery = '''
    SELECT
        CASE addef.dataType
          WHEN 'decimal' THEN
            CASE addef.sigFig
              WHEN 0 THEN ROUND(ad.decimalResult, 0)
              WHEN 1 THEN ROUND(ad.decimalResult, 1)
              WHEN 2 THEN ROUND(ad.decimalResult, 2)
              WHEN 3 THEN ROUND(ad.decimalResult, 3)
              WHEN 4 THEN ROUND(ad.decimalResult, 4)
              WHEN 5 THEN ROUND(ad.decimalResult, 5)
              WHEN 6 THEN ROUND(ad.decimalResult, 6)
            END
          WHEN 'varchar' THEN ad.varcharResult
          WHEN 'dateTime' THEN ad.dateTimeResult
        END AS "result"
    FROM analysisData ad
      INNER JOIN analysisDataRuns adr
        ON ad.analysisDataRunsId = adr.id
      INNER JOIN specimenRuns sr
        ON adr.specimenRunsId = sr.id
      INNER JOIN analysisDataDefinition addef
        ON ad.analysisDataDefinitionId = addef.id
    WHERE sr.runId = ?
      AND ad.analysisDataDefinitionId = ?
  ''' 

  loadValQuery = self.switchboard.connection.prepareStatement(resultQuery)
  loadValQuery.setString(1, runId)
  loadValQuery.setString(2, str(dataDefId))

  rawResult = loadValQuery.executeQuery()

  while rawResult.next():
    thisResult = rawResult.getString(1)


  loadValQuery.close()

  return thisResult



  def makeRow(self, passedJson, runId):
    rowArr = []

    for item in passedJson:
      if item['valType'] == 'specimenId':
        specId = item['value']
        rowArr.append(specId)
      elif item['valType'] == 'specimenLocation':
        specLoc = item['value']
        rowArr.append(specLoc)
      elif item['valType'] == 'loadData':
        loadDataType = item['value']
        loadDataDefId = item['loadDataDefId']
        loadVal = self.getLoadVal(loadDataDefId, runId)
        rowArr.append(loadVal)
      elif item['valType'] == 'metaData':
        metaDataField = item['value']
        metaDataVal = self.getMetaDataVal(metaDataField, runId)
        rowArr.append(metaDataVal)

    return rowArr
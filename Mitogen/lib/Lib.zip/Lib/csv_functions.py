'''
  #
  #   ######## CSV CREATION FUNCTIONS ########
  #
  #     # See groupingContainer.py for implementation
  #
'''

import json
from com.uniconnect.uniflow.exception import SystemException
from java.sql import SQLException

'''
  # Retrieves the configuration for the row by controlRun
  # 
  # @function getConfigByRun
  # @param<string> ctlRunId
  #
  # @return<string> methodVer
  #
'''
def getConfigByCtlRun(switchboard, ctlRunId, methodVer):
  try:
    jsonQuery = '''
      SELECT
        CASE andd.definerType
          WHEN 'metaData' 
            THEN JSON_OBJECT('order', andd.sequence, 'value', fcp.inputName, 'valType', 'metaData') 
          WHEN 'loadData'
            THEN JSON_OBJECT('order', andd.sequence, 'value', andd.dataType, 'valType', 'loadData', 'loadDataDefId', andd.loadDataAnalysisDataDefinitionId)
          WHEN 'specimenColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', cr.currentContainerId, 'valType', 'specimenId')
          WHEN 'locationColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', cr.currentParentPosition, 'valType', 'specimenLocation')
          END AS 'thisJSON'
      FROM analysisDataDefinition andd
      INNER JOIN controlRuns cr ON cr.controlRunId = ?
      LEFT JOIN formInputSettings fis ON fis.id = andd.formInputSettingsId
      LEFT JOIN formConfigurableParts fcp ON fcp.id = fis.formConfigurablePartsId
      LEFT JOIN analysisData ad ON ad.analysisDataDefinitionId = andd.id
      WHERE andd.analysisMethodVersionsId = ?
      ORDER BY andd.sequence
    '''
    jsonStmt = switchboard.connection.prepareStatement(jsonQuery)
    jsonStmt.setString(1, ctlRunId)
    jsonStmt.setString(2, methodVer)
    jsonRs = jsonStmt.executeQuery()
    metaData = jsonRs.getMetaData()
    colNum = metaData.getColumnCount()

    ctlJsonArr = getJsonArray(switchboard, jsonRs, colNum)
    jsonRs.close()
    jsonStmt.close()

    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return ctlJsonArr

'''
  # Retrieves a result set for the configuration by run
  # 
  # @function getConfigByRun
  # @param<string> runId
  #
  # @return<string> methodVer
  #
'''
def getConfigByRun(switchboard, runId, methodVer):
  try: 
    jsonQuery = '''
      SELECT
        CASE andd.definerType
          WHEN 'metaData' 
            THEN JSON_OBJECT('order', andd.sequence, 'value', fcp.inputName, 'valType', 'metaData') 
          WHEN 'loadData'
            THEN JSON_OBJECT('order', andd.sequence, 'value', andd.dataType, 'valType', 'loadData', 'loadDataDefId', andd.loadDataAnalysisDataDefinitionId)
          WHEN 'specimenColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', sr.currentContainerId, 'valType', 'specimenId')
          WHEN 'locationColumn'
            THEN JSON_OBJECT('order', andd.sequence, 'value', sr.currentParentPosition, 'valType', 'specimenLocation')
          END AS 'thisJSON'
      FROM analysisDataDefinition andd
      INNER JOIN specimenRuns sr ON sr.runId = ?
      LEFT JOIN formInputSettings fis ON fis.id = andd.formInputSettingsId
      LEFT JOIN formConfigurableParts fcp ON fcp.id = fis.formConfigurablePartsId
      LEFT JOIN analysisData ad ON ad.analysisDataDefinitionId = andd.id
      WHERE andd.analysisMethodVersionsId = ?
      ORDER BY andd.sequence
    ''' 

    jsonQueryStmt = switchboard.connection.prepareStatement(jsonQuery)
    jsonQueryStmt.setString(1, runId)
    jsonQueryStmt.setString(2, methodVer)
    resSet = jsonQueryStmt.executeQuery()
    metaData = resSet.getMetaData()
    colNum = metaData.getColumnCount()

    thisJsonArr = getJsonArray(switchboard, resSet, colNum)
    jsonQueryStmt.close()
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return thisJsonArr


'''
  # Returns array of value key pairs
  # 
  # @function getJsonArray
  # @param<resultSet> rs
  # @param<int> columnNum
  # 
  # @return<array> jsonArr
  #
'''
def getJsonArray(switchboard, rs, colNum):
  # Init array
  jsonArr = []
  try:
    # Loop rows
    while rs.next():
      # Loop Columns
      for i in range(1,colNum + 1):
        # Convert result to JSON
        thisJSON = json.loads(rs.getString(i))
        # Add JSON to array
        jsonArr.append(thisJSON)

    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return jsonArr

'''
  # Makes a row for analysis download file from JSON array for controls
  # 
  # @param<object> switchboard
  # @param<array>  passedJson
  # @param<string> ctlRunId
  #
  # @return<array> rowArr
  #
'''
def makeCtlRow(switchboard, passedJson, ctlRunId):
  rowArr = []

  try:
    for item in passedJson:
      if item['valType'] == 'specimenId':
        specId = item['value']
        rowArr.append(specId)
      elif item['valType'] == 'specimenLocation':
        specLoc = item['value']
        rowArr.append(blankIfNull(specLoc))
      elif item['valType'] == 'loadData':
        loadDataType = item['value']
        loadDataDefId = item['loadDataDefId']
        loadVal = getCtlLoadVal(switchboard, loadDataDefId, ctlRunId)
        rowArr.append(loadVal)
      elif item['valType'] == 'metaData':
        metaDataVal = ''
        rowArr.append(metaDataVal)

    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return rowArr


'''
  # Makes a row for analysis download file from JSON array
  # 
  # @function makeRow
  # @param<array> passedArr
  #
  # @return<array> rowArr
  #
'''
def makeRow(switchboard, passedJson, runId):
  rowArr = []

  try:
    for item in passedJson:
      if item['valType'] == 'specimenId':
        specId = item['value']
        rowArr.append(specId)
      elif item['valType'] == 'specimenLocation':
        specLoc = item['value']
        rowArr.append(specLoc)
      elif item['valType'] == 'loadData':
        loadDataType = item['value']
        loadDataDefId = item['loadDataDefId']
        loadVal = getLoadVal(switchboard, loadDataDefId, runId)
        rowArr.append(loadVal)
      elif item['valType'] == 'metaData':
        metaDataField = item['value']
        metaDataVal = getMetaDataVal(switchboard, metaDataField, runId)
        rowArr.append(metaDataVal)

    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return rowArr

'''
  # Return single load data value pased on the data definition id and controlRun
  # 
  # @param<int> dataDefId
  # @param<string> ctlRunId
  #
  # @return thisResult 
  #
'''

def getCtlLoadVal(switchboard, dataDefId, ctlRunId):
  loadDataVal = ''
  try:
    ctlQuery = '''
      SELECT 
          CASE addef.dataType
            WHEN 'decimal' THEN
              CASE addef.sigFig
                WHEN 0 THEN ROUND(acd.decimalResult, 0)
                WHEN 1 THEN ROUND(acd.decimalResult, 1)
                WHEN 2 THEN ROUND(acd.decimalResult, 2)
                WHEN 3 THEN ROUND(acd.decimalResult, 3)
                WHEN 4 THEN ROUND(acd.decimalResult, 4)
                WHEN 5 THEN ROUND(acd.decimalResult, 5)
                WHEN 6 THEN ROUND(acd.decimalResult, 6)
              END
            WHEN 'varchar' THEN acd.varcharResult
            WHEN 'dateTime' THEN acd.dateTimeResult
          END AS "result"
      FROM analysisControlData acd
        INNER JOIN analysisControlDataRuns acdr
          ON acd.analysisControlDataRunsId = acdr.id
        INNER JOIN controlRuns cr
          ON acdr.controlRunsId = cr.id
        INNER JOIN analysisDataDefinition addef
          ON acd.analysisDataDefinitionId = addef.id
      WHERE cr.controlRunId = ?
        AND acd.analysisDataDefinitionId = ?
    '''
    ctlStmt = switchboard.connection.prepareStatement(ctlQuery)
    ctlStmt.setString(1, ctlRunId)
    ctlStmt.setString(2, str(dataDefId))
    ctlRs = ctlStmt.executeQuery()

    while ctlRs.next():
      loadDataVal = ctlRs.getString(1)
    ctlRs.close()
    ctlStmt.close()

    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return loadDataVal

'''
  # Return single load data value pased on the data definition id and run
  # 
  # @param<int> dataDefId
  # @param<string> runId
  #
  # @return thisResult 
  #
'''
def getLoadVal(switchboard, dataDefId, runId):
  thisResult = ''
  try:
    resultQuery = '''
      SELECT
          CASE addef.dataType
            WHEN 'decimal' THEN
              CASE addef.sigFig
                WHEN 0 THEN ROUND(ad.decimalResult, 0)
                WHEN 1 THEN ROUND(ad.decimalResult, 1)
                WHEN 2 THEN ROUND(ad.decimalResult, 2)
                WHEN 3 THEN ROUND(ad.decimalResult, 3)
                WHEN 4 THEN ROUND(ad.decimalResult, 4)
                WHEN 5 THEN ROUND(ad.decimalResult, 5)
                WHEN 6 THEN ROUND(ad.decimalResult, 6)
              END
            WHEN 'varchar' THEN ad.varcharResult
            WHEN 'dateTime' THEN ad.dateTimeResult
          END AS "result"
      FROM analysisData ad
        INNER JOIN analysisDataRuns adr
          ON ad.analysisDataRunsId = adr.id
        INNER JOIN specimenRuns sr
          ON adr.specimenRunsId = sr.id
        INNER JOIN analysisDataDefinition addef
          ON ad.analysisDataDefinitionId = addef.id
      WHERE sr.runId = ?
        AND ad.analysisDataDefinitionId = ?
    ''' 

    loadValQuery = switchboard.connection.prepareStatement(resultQuery)
    loadValQuery.setString(1, runId)
    loadValQuery.setString(2, str(dataDefId))

    rawResult = loadValQuery.executeQuery()

    while rawResult.next():
      thisResult = rawResult.getString(1)


    loadValQuery.close()
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return thisResult



'''
  # Return single meta data value based on the field name and run
  # 
  # @param<string> fieldName
  # @param<string> runId
  #
  # @return thisResult 
  #
'''
def getMetaDataVal(switchboard, fieldName, runId):
  thisResult = ''
  try:
    metaDataQuery = '''
      SELECT ''' + fieldName + '''
      FROM vw_runmetadata 
      WHERE runId = ?
    ''' 

    metaValStmt = switchboard.connection.prepareStatement(metaDataQuery)
    metaValStmt.setString(1, runId)
    metaDataRS = metaValStmt.executeQuery()

    while metaDataRS.next():
      thisResult = metaDataRS.getString(1)
    metaValStmt.close()
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
  except Exception as e:
    switchboard.log("---*** EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except StandardError as e:
    switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SystemException as e:
    switchboard.log("---*** UNIFlow SystemException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except SQLException as e:
    switchboard.log("---*** SQLException ***----")
    switchboard.log(str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except BaseException as e:
    switchboard.log("---*** PYTHON EXCEPTION ***---")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except TypeError as e:
    switchboard.log("---*** TYPE ERROR ***----")
    switchboard.log("ERROR MESSAGE: " + str(e.message))
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
  except:
    switchboard.log("---*** UNSPECIFIED ERROR ***---")
    switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  return thisResult

def blankIfNull(value):
  if value == None:
    return ''
  else:
    return value

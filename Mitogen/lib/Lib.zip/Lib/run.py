'''
  #
  # Run class
  #   Creates a run with needed attributes
  #     * See endRun.py for example implementation 
  #     
  # toDo: make attributes private(@property decorator), add setters(@{attr_name}.setter decorator)
  #
'''

import com.uniconnect.uniflow as uniflow
from java.sql import SQLException

## CLASS
class Run:

  '''
    # Class variable used for logging the error location
  '''
  errorLocation = ''

  '''
    # Init function
    #
  '''
  def __init__(self, switchboard, runId):
    self.switchboard = switchboard
    self.runId = runId
    self.curCon = None
    self.curPar = None
    self.curPos = None
    self.methId = None
    self.status = None
    self.wrkFlowRunId = None

    # Set values
    self.setRunValues()

  '''
    # Sets run attributes based on Id
    #
  '''
  def setRunValues(self):
    errorLocation = '<<<<< BEGIN: setRunValues >>>>>'
    runId = self.runId
    cCon  = None
    cPar  = None
    cPos  = None
    mhId  = None
    cRes  = None
    pRun  = None
    try:
      cQuery = '''
        SELECT 
          currentContainerId, 
          currentParentId,
          currentParentPosition,
          specimenMethodsId,
          completedResult,
          parentWorkflowSpecimenRunId
        FROM specimenRuns
        WHERE runId = ?
      '''
      cQueryStmt = self.switchboard.connection.prepareStatement(cQuery)
      cQueryStmt.setString(1, runId)
      cRs = cQueryStmt.executeQuery()
      while cRs.next():
        cCon = cRs.getString('currentContainerId')
        cPar = cRs.getString('currentParentId')
        cPos = cRs.getString('currentParentPosition')
        mhId = cRs.getString('specimenMethodsId')
        cRes = cRs.getString('completedResult')
        pRun = cRs.getString('parentWorkflowSpecimenRunId')
      self.curCon = cCon
      self.curPar = cPar
      self.curPos = cPos
      self.methId = mhId
      self.status = cRes
      self.wrkFlowRunId = pRun
      cRs.close()
      cQueryStmt.close()

      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
      return True

    except Exception as e:
      self.switchboard.log("---*** EXCEPTION ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except StandardError as e:
      self.switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except SystemException as e:
      self.switchboard.log("---*** UNIFlow SystemException ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except SQLException as e:
      self.switchboard.log("---*** SQLException ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except BaseException as e:
      self.switchboard.log("---*** PYTHON EXCEPTION ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except TypeError as e:
      self.switchboard.log("---*** TYPE ERROR ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except:
      self.switchboard.log("---*** UNSPECIFIED ERROR ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return

  ## GETTERS
  def getRunId(self):
    return self.runId

  def getCurrentContainer(self):
    return self.curCon

  def getCurrentParent(self):
    return self.curPar
  
  def getCurrentPosition(self):
    return self.curPos
  
  def getMethodId(self):
    return self.methId
  
  def getCurStatus(self):
    return self.status


  ## Setters

  def setCurrentContainer(self, newCurCon):
    self.curCon = newCurCon

  def setCurrentParent(self, newCurPar):
    self.curPar = newCurPar

  def setCurrentPosition(self, newCurPos):
    self.curPos = newCurPos

  def setMethodId(self, newMethId):
    self.methId = newMethId

  def setCurStatus(self, newStatus):
    self.status = newStatus


  def getAnalysisRes(self):
    errorLocation = '<<<<< BEGIN: getAnalysisRes >>>>>'
    runId = self.getRunId()
    try: 
      curRes = ''
      resQuery = '''
        SELECT adr.result AS 'curRes'
        FROM specimenRuns sr
          INNER JOIN analysisDataRuns adr 
            ON adr.specimenRunsId = sr.id
        WHERE sr.runId = ?
      '''
      resQueryStmt = self.switchboard.connection.prepareStatement(resQuery)
      resQueryStmt.setString(1, runId)
      resRs = resQueryStmt.executeQuery()

      while resRs.next():
        curRes = resRs.getString('curRes')
      resRs.close()
      resQueryStmt.close()

      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
      return curRes

    except Exception as e:
      self.switchboard.log("---*** EXCEPTION ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except StandardError as e:
      self.switchboard.log("---*** STANDRAD PYTHON ERROR ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except SystemException as e:
      self.switchboard.log("---*** UNIFlow SystemException ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except SQLException as e:
      self.switchboard.log("---*** SQLException ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except BaseException as e:
      self.switchboard.log("---*** PYTHON EXCEPTION ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except TypeError as e:
      self.switchboard.log("---*** TYPE ERROR ***----")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return
    except:
      self.switchboard.log("---*** UNSPECIFIED ERROR ***---")
      self.switchboard.log("ERROR LOCATION: " + errorLocation)
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
      raise
      return




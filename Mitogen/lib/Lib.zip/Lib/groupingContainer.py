'''
  #
  # Grouping container class
  #   Implements csv_functions to write configured results to file
  #
'''

import com.uniconnect.uniflow as uniflow
import csv
from java.sql import SQLException
from csv_functions import *
from endRun import EndRun

class GroupingContainer:

  '''
    # Init function
  '''
  def __init__(self, switchboard, contId):
    self.switchboard = switchboard
    self.contId = contId
    self.runIds = []
    self.ctlIds = []
    self.setRunIds()
    self.setControlRunIds()

  ## Getters
  def getContId(self):
    return self.contId

  def getRunIds(self):
    return self.runIds

  def getControlRunIds(self):
    return self.ctlIds

  '''
    # Sets GroupingContainer object runIds based on container id
    #
  '''
  def setRunIds(self):
    containerId = self.getContId()
    runIdArr = []
    try:
      gcQuery = '''
        SELECT runId
        FROM specimenRuns
        WHERE currentParentId = ?
          AND (completedResult <> 'rework' OR completedResult IS NULL)
      ''' 

      gcQueryStmt = self.switchboard.connection.prepareStatement(gcQuery)
      gcQueryStmt.setString(1, containerId)

      
      gcRs = gcQueryStmt.executeQuery()

      while gcRs.next():
        gcRunId = gcRs.getString(1)
        runIdArr.append(gcRunId)
      self.runIds = runIdArr
      gcRs.close()
      gcQueryStmt.close()

      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')

    except SystemException as e:
      self.switchboard.log("---*** UNIFlow SystemException AT GROUPINGCONTAINER SETRUNIDS ***----")
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except SQLException as e:
      self.switchboard.log("---*** SQLException AT GROUPINGCONTAINER SETRUNIDS ***----")
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except:
      self.switchboard.log("---*** UNSPECIFIED ERROR AT GROUPINGCONTAINER SETRUNIDS ***---")
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  '''
    # Sets GroupingContainer object controlRunIds based on container id
    #
  '''
  def setControlRunIds(self):
    containerId = self.getContId()
    conRunIdArr = []
    try:
      crQuery = '''
        SELECT controlRunId
        FROM controlRuns
        WHERE currentParentId = ?
      '''

      crStmt = self.switchboard.connection.prepareStatement(crQuery)
      crStmt.setString(1, containerId)
      crRs = crStmt.executeQuery()

      while crRs.next():
        crRunId = crRs.getString(1)
        conRunIdArr.append(crRunId)
      self.ctlIds = conRunIdArr 
      crRs.close()
      crStmt.close()

      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
    except SystemException as e:
      self.switchboard.log("---*** UNIFlow SystemException AT GROUPINGCONTAINER SETCONTROLRUNIDS ***----")
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except SQLException as e:
      self.switchboard.log("---*** SQLException AT GROUPINGCONTAINER SETCONTROLRUNIDS ***----")
      self.switchboard.log("ERROR MESSAGE: " + str(e.message))
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
    except:
      self.switchboard.log("---*** UNSPECIFIED ERROR AT GROUPINGCONTAINER SETCONTROLRUNIDS ***---")
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')

  '''
    # Ends all runs in the grouping container with passed result
    #
    # @param<string> result
    # @param<long>   eventId
    #
    # @return<bool> 
    #
  '''
  def endRuns(self, result, eventId):

    Runs = self.getRunIds()
    for run in Runs:
      er = EndRun(self.switchboard, run)
      er.endRun(result, eventId)
    return True

  '''
    # Ends all runs in the grouping container with result entered in analyis step (analysisDataRuns table)
    #
    # @param<long>   eventId
    #
    # @return<bool> 
    #
  '''
  def endAnalysisRuns(self, eventId):
    Runs = self.getRunIds()
    for run in Runs:
      er = EndRun(self.switchboard, run)
      er.endAnalysisRun(eventId)
    return True


  '''
    # Retrieves a list of csv formatted values
    # @return<list> csvArrTest
    #
  '''
  def processCSV(self, methodVer):
    
    RunIds = self.getRunIds()
    CtlIds = self.getControlRunIds()
    csvArrTest = []

    for ctlRun in CtlIds:
      ctlJsonArr = getConfigByCtlRun(self.switchboard, ctlRun, methodVer)
      ctlRow = makeCtlRow(self.switchboard, ctlJsonArr, ctlRun)
      csvArrTest.append(ctlRow)

    for run in RunIds:
      thisJsonArr = getConfigByRun(self.switchboard, run, methodVer)
      runRow = makeRow(self.switchboard, thisJsonArr, run)
      csvArrTest.append(runRow)

    return csvArrTest

  '''
    #
    # Writes CSV to given location based on confguration from method version
    #
  '''
  def writeCsv(self, methodVer, filePath):

    listToWrite = self.processCSV(methodVer)

    try:
      with open(filePath, 'w') as f:
        writer = csv.writer(f, dialect='excel')
        writer.writerows(listToWrite)

      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'true')
    except:
      self.switchboard.log("---*** UNSPECIFIED ERROR AT GROUPINGCONTAINER WRITECSV ***---")
      self.switchboard.formResults.put('PROCESSINGSUCCESSFUL', 'false')
